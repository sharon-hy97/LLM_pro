import json
import boto3
import logging
import sys
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import LineBotApiError, InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage
import openai

# 設定 Logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 使用 boto3 客戶端存取 Parameter Store
ssm_client = boto3.client('ssm')

def get_parameter(name):
    try:
        response = ssm_client.get_parameter(Name=name, WithDecryption=True)
        return response['Parameter']['Value']
    except Exception as e:
        logger.error(f"無法從 Parameter Store 獲取參數 {name}: {e}")
        sys.exit(1)

# 從 Parameter Store 獲取必要參數
channel_secret = get_parameter('/linebot/channel_secret')
channel_access_token = get_parameter('/linebot/channel_access_token')
openai_api_key = get_parameter('/openai/api_key')

if not channel_secret or not channel_access_token or not openai_api_key:
    logger.error('無法獲取必要的參數。請檢查 Parameter Store 設定。')
    sys.exit(1)

# 初始化 Line Bot API 和 Webhook Handler
line_bot_api = LineBotApi(channel_access_token)
handler = WebhookHandler(channel_secret)
openai.api_key = openai_api_key

def process_message_async(event):
    """處理用戶訊息的非同步邏輯"""
    user_id = event['source']['userId']
    message_text = event['message']['text']
    logger.info(f'收到 MessageEvent 事件 | 使用者 {user_id} 輸入了 [{message_text}]')

    try:
        # 呼叫 OpenAI API
        completion = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "你是一個客服機器人，請使用正體中文zh-tw回應"},
                {"role": "user", "content": message_text}
            ]
        )
        gpt_response = completion.choices[0].message.content
        logger.info(f"GPT-4 回應: {gpt_response}")

        # 回應用戶
        line_bot_api.push_message(user_id, TextSendMessage(text=gpt_response))
    except Exception as e:
        logger.error(f"處理訊息時發生錯誤: {e}")
        line_bot_api.push_message(
            user_id,
            TextSendMessage(text="抱歉，目前無法處理您的請求，請稍後再試。")
        )

# Lambda Handler 主程式
def lambda_handler(event, context):
    try:
        # 解析事件
        body = json.loads(event['body'])
        logger.info(f"收到事件: {body}")

        # 啟動非同步處理訊息
        process_message_async(body)

        # 立即回應 HTTP 200 狀態碼
        return {'statusCode': 200, 'body': json.dumps('OK')}
    except Exception as e:
        logger.error(f"處理 Lambda 事件時發生錯誤: {e}")
        return {'statusCode': 500, 'body': json.dumps('Internal Server Error')}
